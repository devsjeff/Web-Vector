

export const Services_Components_names = {Whatsapp : "Whatsapp"}