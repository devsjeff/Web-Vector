import style from "./Whatsapp.module.css"
export default function Whatsapp() {
  return (
    <div className={style.Container} >
        <span> Whatsapp</span>
        <div > <span> Accounts</span> <div> <span> 8949493849389</span></div> </div>
        <span> Settings</span>

      
    </div>
  );
}