"use client";

import { useState } from "react";
import { Services } from "../../updates/services/Services";
import style from "./Services.module.css";
import { Fira_Sans } from "next/font/google";
// Import your service components (adjust paths)
import Whatsapp from "../../updates/services/whatsapp/Whatsapp"; // Example
// import ServiceB from "./ServiceB"; // Example
// import ServiceC from "./ServiceC"; // Example

const firaSans = Fira_Sans({
  weight: ["100"],
  subsets: ["latin"],
});

// Map service names (from Services array) to their components
const componentMap = {
  ServiceA: Whatsapp,
  // Add all your services here
};

export default function Service() {
  const [selectedService, setSelectedService] = useState<string | null>(null);

  const closePopup = () => setSelectedService(null);

  // Get the component to render based on selected service
  const SelectedComponent = selectedService
    ? componentMap[selectedService as keyof typeof componentMap]
    : null;

  return (
    <div className={`${style.container} ${firaSans.className}`}>
      <h3 className={style.Services_H3}>Services</h3>

      {/* Service list */}
      <div className={style.ServiceItems}>
        {Services.map((service) => (
          <h2
            key={service}
            onClick={() => setSelectedService(service)}
            className={style.service_item}
          >
            {service}
          </h2>
        ))}
      </div>

      {/* Popup / Modal */}
      {selectedService && SelectedComponent && (
        <div className={style.popupOverlay} onClick={closePopup}>
          <div
            className={style.popupContent}
            onClick={(e) => e.stopPropagation()}
          >
            <button className={style.closeButton} onClick={closePopup}>
              ✕
            </button>
            <SelectedComponent />
          </div>
        </div>
      )}
    </div>
  );
}