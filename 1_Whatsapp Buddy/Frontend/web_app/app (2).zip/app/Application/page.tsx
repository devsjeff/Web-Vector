"use client";

import App_Header from "../components/App_Header";
import Profile from "./components/Profile/profile";
import Service from "./components/Services/Services"

export default function ApplicationPage() {
  return (
    <div>
      <App_Header />
      <Profile />
      <Service/>
    </div>
  );
}


