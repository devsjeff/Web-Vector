"use client";

import Image from "next/image";
import Logo from "../icon.png";
import { Fira_Sans } from "next/font/google";

const firaSans = Fira_Sans({
  weight: "700",
  subsets: ["latin"],
});

export default function App_Header() {

  return (
    <>
      

      <header className="App-site-header">
        <a href="#top" className="brand">
          <Image
            src={Logo}
            alt="Web Vector logo"
            width={38}
            height={38}
            priority
            className="brand-logo"
          />

          <span className={firaSans.className}>WEB VECTOR</span>
        </a>
      </header>
    </>
  );
}