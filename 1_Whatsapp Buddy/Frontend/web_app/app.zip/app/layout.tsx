

export default function RootLayout  (  { children }: { children: React.ReactNode; }     ) {

    return (

        <html lang="en">

        <head>

            <title>WEB VECTOR</title>

        </head>

        <body style={{ margin: 0, padding: 0, boxSizing: "border-box", fontFamily: "Arial, sans-serif" }}>

            {children}
            
        </body>

        </html>

    )
}
