import Image from "next/image";
import Home_background from "./components/utilities/home/background_img.jpg";
import Header from "./components/Home_Header";
import Footer from "./components/Home_Footer" 
import { Jim_Nightshade } from "next/font/google";

const jimNightshade = Jim_Nightshade({
  weight: "400",
  subsets: ["latin"],
});

export default function Page() {
  return (

    <>

    <Header />

    <div  style={{
        position: "relative",
        minHeight: "100vh",
      }}>


      <Image
        src={Home_background}
        alt="Background Image"
        fill
        loading="eager"
      />


      <h1 
      className={jimNightshade.className}
      style={{
        position: "absolute",
        top: "36%",
        left: "45%",
        transform: "translate(-50%, -50%)",
        fontSize: "66px",
        color: "#101b21",
        textShadow: "0 1px 4px rgba(187, 149, 149, 0.35)",
        lineHeight: 1
      }}>
        Command your work Automate the rest
      </h1>


       <h6 
      className={jimNightshade.className}
      style={{
        position: "absolute",
        top: "56%",
        left: "36%",
        transform: "translate(-50%, -50%)",
        fontSize: "16px",
        color: "#d2cac5",
        textShadow: "4px 6px 14px #ccdfb0"

      }}>
        The assistant built for those who move fast and expect more . .
      </h6>


    </div>

    <Footer/>

    </>
  );
}