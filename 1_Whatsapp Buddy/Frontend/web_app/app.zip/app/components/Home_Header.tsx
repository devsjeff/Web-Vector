// import Link from "next/link";
import Image from "next/image";
import Logo from "../icon.png";
import { Fira_Sans } from "next/font/google";

const firaSansExtraLight = Fira_Sans({
  weight: "700",
  subsets: ["latin"],
});


export default function Header() {
  return (

<header
  style={{
    width: "100%",
    zIndex: 10,
    position: "fixed",
    top: 0,
    left: 0,
    margin: 0,
    padding: 0,

    display: "flex",
    alignItems: "center",
    justifyContent: "flex-start",

    backgroundColor: "rgba(42, 65, 78, 0.55)",
    backdropFilter: "blur(16px)",
    WebkitBackdropFilter: "blur(16px)",

    borderBottom: "1px solid rgba(255, 255, 255, 0.08)",
    boxShadow: "0 6px 30px rgba(0, 0, 0, 0.18)",
  }}
>
    <Image style={{ marginLeft: "5px", width: "40px", height: "40px", mixBlendMode: "color-burn" }} src={Logo} alt="LOGO" loading="eager" />
    <span className={firaSansExtraLight.className} style={{ marginLeft: "5px" , fontSize: "1.2rem" }}>  WEB VECTOR </span>
    <button style={{ marginLeft: "auto", marginRight: "10px", padding: "5px 10px",backgroundColor: "#182d38", color: "#fefbeb", border: "none", borderRadius: "6px", cursor: "pointer"  }}> Get Started </button>
</header>



  )
  

}