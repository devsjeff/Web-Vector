export default function Home_Footer() {
    return (
        <footer style={{
            display:"flex" ,
            justifyContent:"center" ,
            alignItems : "center " ,
            height:"100px" ,
            width:"100%",
            backgroundColor: "#101b21", color: "#d2cac5",  textAlign: "center" }}>
            <p>&copy; 2026 WEB VECTOR. All rights reserved.</p>
        </footer>
    );
}